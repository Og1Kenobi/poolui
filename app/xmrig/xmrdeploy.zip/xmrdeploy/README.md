# xmrig-windows-service-scripts
Scripts to set [xmrig](https://github.com/xmrig/xmrig) as a Windows Service

uses built miner from https://github.com/xmrig/xmrig

uses NSSM to run XMRig as windows service https://nssm.cc
